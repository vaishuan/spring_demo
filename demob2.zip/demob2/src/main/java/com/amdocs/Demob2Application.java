package com.amdocs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demob2Application {

	public static void main(String[] args) {
		SpringApplication.run(Demob2Application.class, args);
	}

}
