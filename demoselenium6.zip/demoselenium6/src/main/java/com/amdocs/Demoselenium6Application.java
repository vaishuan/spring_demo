package com.amdocs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demoselenium6Application {

	public static void main(String[] args) {
		SpringApplication.run(Demoselenium6Application.class, args);
	}

}
