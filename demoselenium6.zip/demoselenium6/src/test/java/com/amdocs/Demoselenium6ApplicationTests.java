package com.amdocs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demoselenium6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
